from flask import Flask, request, render_template
import pyodbc

app = Flask(__name__) #creating the Flask class object   
 

cnxn = pyodbc.connect('Driver={SQL Server};'
                      'Server=JEBINS_LAP;'
                      'Database=FARM;'
                      'Trusted_Connection=yes;');
@app.route("/")  
def indexPage():
    mycursor = cnxn.cursor()
    mycursor.execute("select * from BILL")
    data = mycursor.fetchall()
    return render_template("index.html",data=data)

@app.route("/addData", methods=['POST', 'GET'])  
def addData(): 
    if request.method == "POST":
        Sno = request.form['Sno']
        name = request.form['name']
        Date_TIME = request.form['Date']
        Amount = request.form['Amount']
        with cnxn as conn:
            with conn.cursor() as cursor:
                cursor.execute("INSERT INTO BILL VALUES (?, ?, ?, ?)", (Sno, name, Date_TIME, Amount))
            return render_template("addData.html")
    else:
        return render_template('addData.html')  

@app.route("/Retrive, methods=['POST', 'GET'])
def Retrive():
    if request.method == "POST":
        regno = request.form['regno']
        
        with cnxn as conn:
            with conn.cursor() as cursor:
                cursor.execute( "select * from BILL WHERE Sno = ?" ,(Sno) )
                data = cursor.fetchall()
            return render_template("index.html", data=data)
    else:
        return render_template("/Retrive")

if __name__ == '__main__':
    app.debug = True
    app.run()